package com.arishay.pawconnect;

public class Request {
    public String id;
    public String listingId;
    public String rescuerId;
    public String adopterId;
    public String status;
    public String message;

    public String listingName;
    public String adopterEmail;

    public Request() {}
}
